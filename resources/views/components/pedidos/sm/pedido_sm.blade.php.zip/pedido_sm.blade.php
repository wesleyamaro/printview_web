<!-- cabeçalho pedido inicio -->
<div>
    @can('EDIT-PEDIDO', $permissao)
        @include('components.pedidos.sm.editor.cabecalhoPedidoSM') <!-- EDITOR -->
    @else
        @include('components.pedidos.sm.cliente.cabecalhoPedidoSM') <!-- CLIENTE -->
    @endcan
</div>
<!-- cabeçalho pedido fim -->






{{-- <div id="accordion-nested-parent" data-accordion="collapse">

        <!-- Nested accordion -->
        <div id="accordion-nested-collapse" data-accordion="collapse">
          
            <h2 id="accordion-nested-collapse-heading-1">
            <button type="button" class="flex items-center justify-between w-full p-5 rounded-t-xl font-medium rtl:text-right text-gray-500 border border-b-0 border-gray-200 focus:ring-4 focus:ring-gray-200 dark:focus:ring-gray-800 dark:border-gray-700 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 gap-3" data-accordion-target="#accordion-nested-collapse-body-1" aria-expanded="false" aria-controls="accordion-nested-collapse-body-1">
              <span>Informações do pedido</span>
             <svg data-accordion-icon class="w-3 h-3 rotate-180 shrink-0" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 10 6">
                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5 5 1 1 5"/>
              </svg>
            </button>
          </h2>
          <div id="accordion-nested-collapse-body-1" class="hidden" aria-labelledby="accordion-nested-collapse-heading-1">
            <div class="border border-b-0 border-gray-200 dark:border-gray-700">
              

                <!-- complemento pedido inicio -->
                <div>  
                    @can('EDIT-PEDIDO', $permissao)
                        @include('components.pedidos.sm.editor.complementoPedidoSM') <!-- EDITOR -->
                    @else
                        @include('components.pedidos.sm.cliente.complementoPedidoSM') <!-- CLIENTE -->
                    @endcan
                </div>
                <!-- complemento pedido fim -->

            </div>
          </div>

          <h2 id="accordion-nested-collapse-heading-2">
            <button type="button" class="flex items-center justify-between w-full p-5 font-medium rtl:text-right text-gray-500 border border-b-0 border-gray-200 focus:ring-4 focus:ring-gray-200 dark:focus:ring-gray-800 dark:border-gray-700 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 gap-3" data-accordion-target="#accordion-nested-collapse-body-2" aria-expanded="false" aria-controls="accordion-nested-collapse-body-2">
              <span>Itens do pedido</span>
              <svg data-accordion-icon class="w-3 h-3 rotate-180 shrink-0" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 10 6">
                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5 5 1 1 5"/>
              </svg>
            </button>
          </h2>

          <div id="accordion-nested-collapse-body-2" class="hidden" aria-labelledby="accordion-nested-collapse-heading-2">
            <div class="border border-b-0 border-gray-200 dark:border-gray-700">
             

                <!-- itens pedido inicio -->
                <div>
                    @can('EDIT-PEDIDO', $permissao)
                        @include('components.pedidos.sm.editor.itensPedidoSM') <!-- EDITOR -->
                    @else
                        @include('components.pedidos.sm.cliente.itensPedidoSM') <!-- CLIENTE -->
                    @endcan
                </div>
                <!-- itens pedido fim -->

                
            </div>
          </div>

 

        </div>
        <!-- End: Nested accordion -->

  
  </div> --}}


  <div x-data="{ tab: 'first' }">
    <!--TAB - INICIO-->
    <div class="flex">
        <button :class="{ 'active': tab === 'first', 'text-orange-600 dark:text-orange-500 border-t-2 border-x-2 border-b-0 border-gray-300 dark:border-slate-600'
        : tab === 'first', 'border-b-2 border-gray-300 dark:border-slate-600'
        : tab !== 'first' }" @click="tab = 'first'" 
        class="text-gray-600 dark:text-gray-400 py-1 px-3 rounded-t-lg text-sm md:text-base">
            Itens do pedido
        </button>

        <button :class="{ 'active': tab === 'second', 'text-orange-600 dark:text-orange-500 border-t-2 border-x-2 border-b-0 border-gray-300 dark:border-slate-600'
        : tab === 'second', 'border-b-2 border-gray-300 dark:border-slate-600'
        : tab !== 'second' }" @click="tab = 'second'" 
        class="text-gray-600 dark:text-gray-400 py-1 px-3 rounded-t-md text-sm md:text-base">
            Informações do pedido
        </button>


    </div>
    <!--TAB - FIM-->
    
    <!--TABS - INICIO-->
    <div class="bg-gray-200 dark:bg-slate-800  rounded-b-lg">
        <div x-show="tab === 'first'" >
            <div class="mt-2  min-h-65v  max-h-65v soft-scrollbar overflow-y-auto">
                
                
                 <!-- itens pedido inicio -->
                 <div>
                    @can('EDIT-PEDIDO', $permissao)
                        @include('components.pedidos.sm.editor.itensPedidoSM') <!-- EDITOR -->
                    @else
                        @include('components.pedidos.sm.cliente.itensPedidoSM') <!-- CLIENTE -->
                    @endcan
                </div>
                <!-- itens pedido fim -->


            </div>
        </div>
    
        <div x-show="tab === 'second'">
            <div class="mt-2 min-h-65v max-h-65v soft-scrollbar overflow-y-auto">
                
                
                <!-- complemento pedido inicio -->
                <div>  
                    @can('EDIT-PEDIDO', $permissao)
                        @include('components.pedidos.sm.editor.complementoPedidoSM') <!-- EDITOR -->
                    @else
                        @include('components.pedidos.sm.cliente.complementoPedidoSM') <!-- CLIENTE -->
                    @endcan
                </div>
                <!-- complemento pedido fim -->

            </div>
        </div>

    </div>
    <!--TABS - FIM-->

</div>