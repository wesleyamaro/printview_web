<div>
    <x-notifications z-index="z-50" />

    <div class="flex items-center justify-between bg-green-700  rounded-lg ">
        @if (session()->has('error'))
            <div class="flex items-center w-full  h-10 alert bg-red-600 text-white">
                {{ session('error') }}
            </div>
        @endif
    </div>

   {{--  <x-slot name="header" class="flex justify-between "> --}}
    <div name="headers" class="mb-2 bg-gray-200 dark:bg-gray-800 shadow">

       <div class="md:w-10/12 mx-auto py-2 px-2 sm:px-6 lg:px-2">
            <h2 class="flex items-center justify-between font-semibold text-xl text-orange-600 dark:text-orange-500 leading-tight">
                <div class="flex gap-x-2 ">
                    <svg class="w-5 h-5 text-orange-600 dark:text-orange-500 " viewBox="0 0 29 27" xmlns="http://www.w3.org/2000/svg" xml:space="preserve" style="fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2">
                        <path d="M23.623 20.812s.39-1.627.874-3.038c.758-2.21 2.898-5.41 3.639-7.755.439-1.357.677-2.857.252-4.102-.443-1.294-.915-2.429-1.876-3.709C25.534.906 24.209.164 22.628.011c-1.125-.109-2.048.608-2.659 1.416-1.022 1.351-1.404 3.031-1.823 4.66-.597 2.314-.519 4.002-.232 5.589.151 2.132-.369 3.41-.946 4.944-1.16 3.08-2.087 5.366-1.867 6.474.39 1.315 1.086 2.151 2.365 2.6 1.483.52 2.656.723 3.58.184 1.021-.597 1.583-1.483 1.884-2.538l.693-2.528zM4.988 20.812s-.39-1.627-.874-3.038c-.758-2.21-2.898-5.41-3.64-7.755C.036 8.662-.202 7.162.223 5.917c.442-1.294.915-2.429 1.875-3.709C3.076.906 4.401.164 5.983.011 7.108-.098 8.03.619 8.641 1.427c1.022 1.351 1.404 3.031 1.824 4.66.596 2.314.519 4.002.231 5.589-.15 2.132.369 3.41.947 4.944 1.16 3.08 2.086 5.366 1.867 6.474-.391 1.315-1.087 2.151-2.365 2.6-1.483.52-2.656.723-3.58.184-1.022-.597-1.583-1.483-1.884-2.538l-.693-2.528z" 
                        style="fill:rgb(208 56 1)"/>
                    </svg>
                    {{ __('Top 50 mais vendidas') }}
                
                </div>



                <div class="flex items-center justify-between gap-x-2">
                    
                    <!-- Cart -->
                    <div class="hidden ml-4 md:flow-root mr-2">
                        <a  href="{{ route('carrinho_compra') }}" class="group -m-2 flex items-center p-2">
                        <svg class="h-6 w-6 flex-shrink-0 text-blue-500 group-hover:text-blue-400" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 10.5V6a3.75 3.75 0 10-7.5 0v4.5m11.356-1.993l1.263 12c.07.665-.45 1.243-1.119 1.243H4.25a1.125 1.125 0 01-1.12-1.243l1.264-12A1.125 1.125 0 015.513 7.5h12.974c.576 0 1.059.435 1.119 1.007zM8.625 10.5a.375.375 0 11-.75 0 .375.375 0 01.75 0zm7.5 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" />
                        </svg>
                        <span class="ml-2 text-sm font-medium text-gray-400 group-hover:text-gray-400">{{ $quantidadeCart}}</span>
                        <span class="sr-only">items in cart, view bag</span>
                        </a>
                    </div>
                
                    <div class="flow-root md:hidden mr-2">
                        <a data-drawer-target="menu-cart" data-drawer-show="menu-cart" href="#" class="group -m-2 flex items-center p-2">
                        <svg class="h-6 w-6 flex-shrink-0 text-green-500 group-hover:text-green-400" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 10.5V6a3.75 3.75 0 10-7.5 0v4.5m11.356-1.993l1.263 12c.07.665-.45 1.243-1.119 1.243H4.25a1.125 1.125 0 01-1.12-1.243l1.264-12A1.125 1.125 0 015.513 7.5h12.974c.576 0 1.059.435 1.119 1.007zM8.625 10.5a.375.375 0 11-.75 0 .375.375 0 01.75 0zm7.5 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" />
                        </svg>
                        <span class="ml-2 text-sm font-medium text-gray-400 group-hover:text-gray-400">{{ $quantidadeCart }}</span>
                        <span class="sr-only">items in cart, view bag</span>
                        </a>
                    </div>
                
                       
                </div>

                
            </h2>
        </div>
    </div>
     {{-- </x-slot> --}}

     @include('components.menu-cart')
   
     @php
        $maxQuantidade = $produtoList->max('quantidade'); // Obtém a quantidade máxima entre todos os produtos
     @endphp

    <div class="w-full md:w-11/12 mx-auto sm:px-2 md:px-2 lg:p-3 bg-gray-200 dark:bg-slate-800 rounded-lg">
        


        <div  class="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-12 xl:grid-cols-12 content-start px-1 gap-1 md:gap-2 mb-0 md:mb-3 rounded-lg  overflow-y-auto soft-scrollbar max-h-77v md:max-h-70v">
            


        @forelse ($produtoList as $transfer)
            @if (!in_array($transfer->id, $carrinho))

                <div x-data="{ showModal: false }" wire:key="{{ $transfer->produto->id }}" class="col-span-1 h-44 md:h-48 rounded-lg bg-white dark:bg-slate-700 p-1 shadow-lg">
                  
                     <!-- inicio card -->

                     @php
                        $rating = ($transfer->quantidade / $maxQuantidade) * 5; // Calcula o rating proporcional à quantidade vendida
                    @endphp
                    {{-- @php
                        $maxQuantidade = some_value; // Replace 'some_value' with the actual value or calculation

                        if ($maxQuantidade != 0) {
                            $rating = ($transfer->quantidade / $maxQuantidade) * 5; // Calcula o rating proporcional à quantidade vendida
                        } else {
                            $rating = 0; // Assign a default value or handle the error appropriately
                        }
                    @endphp --}}


                    
                        <div class=" rounded-t-lg bg-white flex justify-center">
                            <img @click="showModal = true" src="{{ $transfer->produto->imagem ? asset('storage/' . $transfer->produto->imagem) : 'https://cdn1.staticpanvel.com.br/produtos/15/produto-sem-imagem.jpg' }}" alt="Produto sem foto. Avise-nos!" class="h-img-produto md:h-36  rounded-t-lg cursor-pointer" oncontextmenu="return false;" />
                        </div>

                        <div class="p-1 text-center ">


                            <div class="flex items-center">
                                @for($i = 1; $i <= 5; $i++)
                                    @if($i <= $rating)
                                        <svg class="w-2 h-2 text-yellow-300 ms-1" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 22 20">
                                            <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"/>
                                        </svg>
                                    @else
                                        <svg class="w-2 h-2 ms-1 text-gray-300 dark:text-gray-500" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 22 20">
                                            <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"/>
                                        </svg>
                                    @endif
                                @endfor
                            </div>

                           
                            <div class="flex justify-center w-full clear-left text-center py-1 md:py-2 ">
                                <span class="font-bold text-sm text-gray-600 dark:text-gray-300">{{ $transfer->produto->referencia }}</h1>
                            </div>

                                <button wire:click="addCarrinho({{ $transfer->produto->id }})" wire:loading.attr="disabled" type="button" class="relative bottom-16 left-1 float-right inline-flex items-center rounded-full border-2 bg-green-700 p-1.5 text-center text-sm font-medium text-white hover:bg-green-800 focus:outline-none focus:ring-4 focus:ring-green-300 dark:bg-green-600 dark:hover:bg-green-700 dark:focus:ring-green-800">
                                    <svg class="h-5 w-5 text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 21">
                                    <path d="M15 14H7.78l-.5-2H16a1 1 0 0 0 .962-.726l.473-1.655A2.968 2.968 0 0 1 16 10a3 3 0 0 1-3-3 3 3 0 0 1-3-3 2.97 2.97 0 0 1 .184-1H4.77L4.175.745A1 1 0 0 0 3.208 0H1a1 1 0 0 0 0 2h1.438l.6 2.255v.019l2 7 .746 2.986A3 3 0 1 0 10 17a2.966 2.966 0 0 0-.184-1h2.368c-.118.32-.18.659-.184 1a3 3 0 1 0 3-3Zm-8 4a1 1 0 1 1 0-2 1 1 0 0 1 0 2Zm8 0a1 1 0 1 1 0-2 1 1 0 0 1 0 2Z" />
                                    <path d="M19 3h-2V1a1 1 0 0 0-2 0v2h-2a1 1 0 1 0 0 2h2v2a1 1 0 0 0 2 0V5h2a1 1 0 1 0 0-2Z" />
                                    </svg>
                                </button>                                


                        </div>
                    
                    <!-- fim card -->
                    

                 <!-- Alpine.js Modal -->
                 <div x-show="showModal" @click.away="showModal = false" class="z-50 fixed inset-0 overflow-y-auto" style="display: none;">
                  
                    <div class="flex items-start justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
                        <div class="fixed inset-0 transition-opacity" aria-hidden="true">
                            <div class="absolute inset-0 bg-gray-500 opacity-75"></div>
                        </div>

                        <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>

                        
                        <div @click.away="showModal = false" x-show="showModal" class="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-2xl sm:w-full p-2" style="width: 100%;">
                            <div class="p-2 bg-gray-200 rounded-lg">
                                <h1 class="text-center font-bold text-green-600">{{ $transfer->produto->referencia }}</h1>
                            </div>
                            <div>
                                <img src="{{ url("storage/{$transfer->produto->imagem}") }}" alt="" class="mx-auto {{-- w-full --}} md:h-700p rounded-lg" oncontextmenu="return false;">
                            </div>

                            <div class="flex justify-between px-1">
                                <div class="flex items-center gap-x-2"> 
                                   <strong class="text-gray-600">Filtros:</strong> <h1 class="text-xs text-gray-400 uppercase">{{ $transfer->produto->filtros }}</h1> 
                                </div>
                                @can('QNDE-MAISVENDIDOS', $permissao)
                                    <div>
                                        <span class="text-sm text-blue-500 font-bold">Total vendido(s):   {{ $transfer->quantidade ?? 0 }}</span>
                                    </div>
                                @endcan                               
                            </div>

                            <div class="p-3 w-full ">
                                <button wire:click="addCarrinho({{ $transfer->produto->id }})" wire:loading.attr="disabled" type="button"
                                    class="w-full justify-center text-white bg-green-700 hover:bg-green-800 focus:ring-0 focus:outline-none focus:ring-green-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center inline-flex items-center mr-2 dark:bg-green-600 dark:hover:bg-green-700 dark:focus:ring-green-800">
                                    <svg class="w-3.5 h-3.5 mr-2" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                                        fill="currentColor" viewBox="0 0 18 21">
                                        <path
                                            d="M15 12a1 1 0 0 0 .962-.726l2-7A1 1 0 0 0 17 3H3.77L3.175.745A1 1 0 0 0 2.208 0H1a1 1 0 0 0 0 2h.438l.6 2.255v.019l2 7 .746 2.986A3 3 0 1 0 9 17a2.966 2.966 0 0 0-.184-1h2.368c-.118.32-.18.659-.184 1a3 3 0 1 0 3-3H6.78l-.5-2H15Z" />
                                    </svg>
                                    Adicionar ao carrinho
                                </button>
                            </div>
                              
                            
                        </div>
                        
                    </div>
                </div>
                <!--Alpine.js Modal - Fim -->
            </div>

            @endif

        @empty
        <div class="col-span-full text-center">
            <h1 class="md:text-2xl text-red-600 dark:text-red-400">Nenhum registro encontrado.</h1>
        </div>
        @endforelse

        {{-- <div class="p-1" id="jeremias" x-data="{
            jeremias(){
                const observer = new IntersectionObserver((produtoList) => {
                    produtoList.forEach((transfer) => {
                        if(transfer.isIntersecting){
                            @this.loadMore()
                        }
                        
                    })
                })
                observer.observe(this.$el)
            }
        }" x-init="jeremias"></div> --}}



    

        </div>
        
    </div>

</div>