<?php

namespace App\Livewire\Produtos;

use Livewire\Component;

use App\Models\Produto;
use App\Models\ItemPedido;

use App\Models\Marca;
use App\Models\CarrinhoCompra;
use Livewire\WithPagination;
use Livewire\Attributes\On;
use WireUi\Traits\Actions;

class MaisVendidos extends Component
{

    use Actions;
    use WithPagination; 

    public $search = '';

    public $marcaList;
    public $selectedMarca ='';
    
    public $filtro = '';

    public $searchMarca = '';
    public $imagem = '';
    public $referencia;
    public $genero = '';
    public $id_produtoinfo;
    public bool $myModalCart = false;
    public $carrinho = []; // Itens do carrinho temporário
    public bool $myModal = false;

    //public $qtpagina = 10; // Defina o número inicial de itens por página
    public $page = 1;
    public $items = [];


    public $perPage = 100;


    public function mount()
    {
        $user = auth()->user();
        $this->marcaList = $user->brands()->get();
    }

    //Adiciona produtos ao carrinho - inicio
    public function addCarrinho($produtoId) {
        $user = auth()->user();
        
        $produto = Produto::find($produtoId);
        
        // Verifica se o produto já está no carrinho do usuário
        $itemCarrinho = CarrinhoCompra::where('user_id', $user->id)
            ->where('produto_id', $produtoId)
            ->first();
    
        if ($itemCarrinho) {
            // Se o produto já estiver no carrinho, aumenta a quantidade em 1
            $itemCarrinho->increment('quantidade');
        } else { 
            // Caso contrário, cria um novo item no carrinho com quantidade 1
            CarrinhoCompra::create([
                'produto_id' => $produtoId,
                'quantidade' => 120,
                'quantidade' => 120,
                'user_id' => $user->id,
            ]);
        } 
    
        if (!in_array($produtoId, $this->carrinho)) {
            $this->carrinho[] = $produtoId;
        }
        $this->myModal = false;
        $this->dispatch('produto-addCart', $produto);
        /* $this->dispatch('showAddCart'); */
        
        /*
        $this->notification()->success(
            $title = 'Sucesso!',
            $description = 'Produto adicionado ao carrinho.'
        );*/
        $this->dispatch('success',  title: 'Produto adicionado ao carrinho.', );
    }
    //ADICIONAR PRODUTO AO CARRINHO -FIM



    public function resetFilters()
    {
        $this->reset('search');
        $this->reset('selectedMarca');    
        $this->reset('searchMarca');
        $this->reset('genero');  
    }
      //Paginate auto
      public function loadMore()
      {
          $this->perPage += 50;
      }
      
      public function buscarEstampa()
      {
          $this->render();
          $this->myModalCart = false;
      }

 
      
      public function render()
    {
        $user = auth()->user();


        $produtos = ItemPedido::whereHas('produto.marca.user_brand', function ($query) use ($user) {
            $query->where('users.id', $user->id);
        })->whereDoesntHave('produto.blockedUsers', function ($query) use ($user) {
            $query->where('users.id', $user->id);
        });
       
        
        // Verifica se a marca selecionada não está vazia
        if ($this->selectedMarca) {
            $this->resetPage();//Reseta o paginate
            $produtos->where('marca_id', $this->selectedMarca)
                ->where(function ($query) {
                    
                    if (!empty($this->genero)) {
                        $this->resetPage();//Reseta o paginate
                        $query->where('genero', $this->genero);
                    }

                    $query->where('referencia', 'like', '%' . $this->search . '%')
                        ->orWhere('filtros', 'like', '%' . $this->search . '%');
                    
                        if (!empty($this->genero)) {
                            $this->resetPage();//Reseta o paginate
                            $query->where('genero', $this->genero);
                        }
                });
        } else {
            $produtos->where(function ($query) {

                if (!empty($this->genero)) {
                    $this->resetPage();//Reseta o paginate
                    $query->orWhere('genero', $this->genero);
                }
                if ($this->search) {
                    $this->resetPage(); //Reseta o paginate
                    $query->where('filtros', 'like', '%' . $this->search . '%')
                        ->orWhere('referencia', 'like', '%' . $this->search . '%');
                }
                
            });
        }


         $produtos = $produtos->groupBy('produto_id')
        ->selectRaw('produto_id, sum(quantidade) as quantidade')
        ->orderBy('quantidade', 'desc')
        ->take(50)
        ->get(); 
        
      /*  
        //Dar certo. Porem exibi os itens que ainda não tem a foto cadastrada no sistema
        // Supondo que 'ItemPedido' tem um relacionamento 'pedido' definido para acessar seu pedido associado
            $produtos = ItemPedido::whereHas('pedido', function ($query) {
                $query->where('status', '=', 'entregue');
                
            })->with('pedido') // Opcional: carregar os dados do pedido junto com cada item, se necessário
            ->groupBy('produto_id')
            ->selectRaw('produto_id, sum(quantidade) as quantidade')
            ->orderBy('quantidade', 'desc')
            ->take(50)
            ->get();
                */


        return view('livewire.produtos.mais-vendidos', [           
            'produtoList' => $produtos,         
            'quantidadeCart' => CarrinhoCompra::where('user_id', $user->id)->count(),
        ]);
    }

}
